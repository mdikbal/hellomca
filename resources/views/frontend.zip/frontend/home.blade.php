
@extends('frontend.frontapp')
@section('content')
    @include('frontend.block.banner_one')
    @include('frontend.widget.home_service_one')
    @include('frontend.widget.large_message_button')
    @include('frontend.widget.list_msg_left_image')
    @include('frontend.widget.home_video_banner')
    @include('frontend.widget.list_msg_right_image')
    @include('frontend.widget.team_home')
    @include('frontend.widget.twitter_banner')
@stop

