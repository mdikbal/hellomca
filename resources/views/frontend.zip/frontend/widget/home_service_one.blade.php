<section class="b-desc-section-container b-diagonal-line-bg-light">
    <div class="container">
        <h2 class="f-center f-primary-b">why choose us ?</h2>
        <p class="b-desc-section f-desc-section f-center f-primary-l">Etiam consectetur pellentesque justo. Sed tristique bibendum elit non molestie. Donec et libero rutrum</p>
        <div class="b-hr-stars f-hr-stars">
            <div class="b-hr-stars__group">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
            </div>
        </div>
        <div class="b-infoblock-with-icon-group row">
            
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="b-infoblock-with-icon">
                    <a href="#" class="b-infoblock-with-icon__icon f-infoblock-with-icon__icon fade-in-animate">
                        <i class="fa fa-tint"></i>
                    </a>
                    <div class="b-infoblock-with-icon__info f-infoblock-with-icon__info">
                        <a href="#" class="f-infoblock-with-icon__info_title b-infoblock-with-icon__info_title f-primary-sb">Unique and morden design</a>
                        <div class="f-infoblock-with-icon__info_text b-infoblock-with-icon__info_text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut massa in
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="b-infoblock-with-icon">
                    <a href="#" class="b-infoblock-with-icon__icon f-infoblock-with-icon__icon fade-in-animate">
                        <i class="fa fa-spinner"></i>
                    </a>
                    <div class="b-infoblock-with-icon__info f-infoblock-with-icon__info">
                        <a href="#" class="f-infoblock-with-icon__info_title b-infoblock-with-icon__info_title f-primary-sb">Unlimited color schemes</a>
                        <div class="f-infoblock-with-icon__info_text b-infoblock-with-icon__info_text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut massa in
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix visible-sm-block"></div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="b-infoblock-with-icon">
                    <a href="#" class="b-infoblock-with-icon__icon f-infoblock-with-icon__icon fade-in-animate">
                        <i class="fa fa-th-large"></i>
                    </a>
                    <div class="b-infoblock-with-icon__info f-infoblock-with-icon__info">
                        <a href="#" class="f-infoblock-with-icon__info_title b-infoblock-with-icon__info_title f-primary-sb">10+ homepage layout</a>
                        <div class="f-infoblock-with-icon__info_text b-infoblock-with-icon__info_text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut massa in
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix visible-md-block visible-lg-block"></div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="b-infoblock-with-icon">
                    <a href="#" class="b-infoblock-with-icon__icon f-infoblock-with-icon__icon fade-in-animate">
                        <i class="fa fa-shopping-cart"></i>
                    </a>
                    <div class="b-infoblock-with-icon__info f-infoblock-with-icon__info">
                        <a href="#" class="f-infoblock-with-icon__info_title b-infoblock-with-icon__info_title f-primary-sb">Awesome e-commerce</a>
                        <div class="f-infoblock-with-icon__info_text b-infoblock-with-icon__info_text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut massa in
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix visible-sm-block"></div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="b-infoblock-with-icon">
                    <a href="#" class="b-infoblock-with-icon__icon f-infoblock-with-icon__icon fade-in-animate">
                        <i class="fa fa-files-o"></i>
                    </a>
                    <div class="b-infoblock-with-icon__info f-infoblock-with-icon__info">
                        <a href="#" class="f-infoblock-with-icon__info_title b-infoblock-with-icon__info_title f-primary-sb">50+ inner pages included</a>
                        <div class="f-infoblock-with-icon__info_text b-infoblock-with-icon__info_text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut massa in
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="b-infoblock-with-icon">
                    <a href="#" class="b-infoblock-with-icon__icon f-infoblock-with-icon__icon fade-in-animate">
                        <i class="fa fa-font"></i>
                    </a>
                    <div class="b-infoblock-with-icon__info f-infoblock-with-icon__info">
                        <a href="#" class="f-infoblock-with-icon__info_title b-infoblock-with-icon__info_title f-primary-sb">Free fonts and icons</a>
                        <div class="f-infoblock-with-icon__info_text b-infoblock-with-icon__info_text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut massa in
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix visible-sm-block"></div>
        </div>
    </div>
</section>
