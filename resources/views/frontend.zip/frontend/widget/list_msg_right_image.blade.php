

<section class="b-diagonal-line-bg-light b-section-info b-section-info__img-r f-section-info__img-r">
    <div class="container">
        <div class="row">
            <div class="b-section-info__img col-sm-6 col-xs-12">
                {!! Html::image('assets/frontend/img/animation-data/responsive_img_2.png','alt-text', array('class'=>'j-data-element','data-retina' => 'data-retina','data-animate'=>'fadeInRight'))!!}

            </div>
            <div class="b-section-info__text f-section-info__text col-sm-6 col-xs-12">
                <h2 class="f-primary-b">about frexy template</h2>
                <p class="f-section-info__text_short">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque luctus ipsum nenatis mi auctor ullamcorper.</p>
                <hr class="b-hr-light"/>
                <div class="b-section-info__text_group">
                    <ul class="c-primary c--inherit b-list-markers f-list-markers b-list-markers--without-leftindent f-list-markers--medium f-color-primary b-list-markers-2col f-list-markers-2col">
                        <li><a href="#"><i class="fa fa-check-circle-o b-list-markers__ico f-list-markers__ico"></i> 10+ Homepage versions</a></li>
                        <li><a href="#"><i class="fa fa-check-circle-o b-list-markers__ico f-list-markers__ico"></i> 10+ shortcode files</a></li>
                        <li><a href="#"><i class="fa fa-check-circle-o b-list-markers__ico f-list-markers__ico"></i> 15+ blog layouts</a></li>
                        <li><a href="#"><i class="fa fa-check-circle-o b-list-markers__ico f-list-markers__ico"></i> 30+ inner pages</a></li>
                        <li><a href="#"><i class="fa fa-check-circle-o b-list-markers__ico f-list-markers__ico"></i> 0+ Portfolio layout</a></li>
                        <li><a href="#"><i class="fa fa-check-circle-o b-list-markers__ico f-list-markers__ico"></i> and much more...</a></li>
                        <li><a href="#"><i class="fa fa-check-circle-o b-list-markers__ico f-list-markers__ico"></i> E-commerce intergrated</a></li>
                    </ul>
                    <a href="#" class="b-btn f-btn b-btn-default b-btn-md f-primary-b">request a quote</a>
                </div>
            </div>
        </div>
    </div>
</section>
