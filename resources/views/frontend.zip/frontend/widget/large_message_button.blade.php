<section class="b-bg-block f-bg-block b-bg-block-meadow">
    <div class="container f-center">
        <h1 class="f-primary-b">modern. creative. unique.</h1>
        <div class="b-bg-block__desc f-bg-block__desc f-primary">Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus</div>
        <a class="b-btn f-btn b-btn-md f-btn-md b-btn-primary f-primary-sb j-data-element" data-animate="shake" href="frexy/demo.html"><i class="fa fa-desktop"></i> view demo</a>
        <span class="clearfix visible-xs-block"></span>
        <a class="b-btn f-btn b-btn-md f-btn-md f-primary-sb j-data-element" data-animate="shake" href="about_us_pricing.html"><i class="fa fa-money"></i> purchase it</a>
    </div>
</section>