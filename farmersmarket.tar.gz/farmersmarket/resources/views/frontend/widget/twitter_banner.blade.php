
<div class="b-slider-primary" >
    <div class="j-slider-primary">
        <div class="b-slider-primary-item b-slider-primary-item--bg f-slider-primary-item">
            <div class="container">
                <div class="f-slider-primary-item__title b-slider-primary-item__title f-primary-b">
                    <i class="fa fa-twitter"></i><br/>
                    <span><b>@frexystudio</b></span>
                </div>
                <p class="b-slider-primary-item__text f-slider-primary-item__text f-primary-l">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In accumsan porttitor egestas.<br/> Suspendisse gravida ultrices convallis. Interdum et malesuada fames<br/>
                    <a href="http://bly.shotlinks.com">http://bly.shotlinks.com</a></p>
            </div>
        </div>
        <div class="b-slider-primary-item b-slider-primary-item--bg1 f-slider-primary-item">
            <div class="container">
                <div class="f-slider-primary-item__title b-slider-primary-item__title f-primary-b">
                    <i class="fa fa-facebook"></i><br/>
                    <span><b>@frexystudio</b></span>
                </div>
                <p class="b-slider-primary-item__text f-slider-primary-item__text f-primary-l">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In accumsan porttitor egestas.<br/> Suspendisse gravida ultrices convallis. Interdum et malesuada fames<br/>
                    <a href="http://bly.shotlinks.com">http://bly.shotlinks.com</a></p>
            </div>
        </div>
        <div class="b-slider-primary-item b-slider-primary-item--bg2 f-slider-primary-item">
            <div class="container">
                <div class="f-slider-primary-item__title b-slider-primary-item__title f-primary-b">
                    <i class="fa fa-linkedin"></i><br/>
                    <span><b>@frexystudio</b></span>
                </div>
                <p class="b-slider-primary-item__text f-slider-primary-item__text f-primary-l">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In accumsan porttitor egestas.<br/> Suspendisse gravida ultrices convallis. Interdum et malesuada fames<br/>
                    <a href="http://bly.shotlinks.com">http://bly.shotlinks.com</a></p>
            </div>
        </div>
    </div>
</div>
