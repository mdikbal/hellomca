
@extends('frontend.frontapp')
@section('content')
    <section class="b-infoblock--small">
        <div class="container">
            <div class="row b-col-default-indent">
                <div class="col-md-9">
                    <p class="f-primary-b f-uppercase f-title-small c-primary">Frequently asked questions</p>

                    <div class="j-accordion b-accordion f-accordion b-accordion--secondary b-accordion--with-icon-indent f-accordion--secondary">
                        <h3 class="b-accordion__title f-accordion__title f-primary-b"><i
                                class="fa fa-question-circle"></i> Donec ut purus sed tortor malesuada venenatis eget
                        </h3>

                        <div class="b-accordion__content">
                            <p>Mauris rhoncus pretium porttitor. Cras scelerisque commodo odio. Phasellus dolor enim,
                                faucibus egestas scelerisque hendrerit, aliquet sed lorem. Pellentesque et pulvinar
                                enim. Quisque at tempor ligula. Maecenas augue ante, euismod vitae egestas sit amet,
                                accumsan eu nulla. <br/>
                                <a href="blog_detail_left_slidebar.html" class="f-more f-primary-b">Read more</a></p>
                        </div>
                        <h3 class="b-accordion__title f-accordion__title f-primary-b"><i
                                class="fa fa-question-circle"></i> Suspendisse vitae lectus in tellu</h3>

                        <div class="b-accordion__content">
                            <p>Mauris rhoncus pretium porttitor. Cras scelerisque commodo odio. Phasellus dolor enim,
                                faucibus egestas scelerisque hendrerit, aliquet sed lorem. Pellentesque et pulvinar
                                enim. Quisque at tempor ligula. Maecenas augue ante, euismod vitae egestas sit amet,
                                accumsan eu nulla. At vero eos et accusamus et iusto odio dignissimos ducimus qui
                                blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas. <br/>
                                <a href="blog_detail_left_slidebar.html" class="f-more f-primary-b">Read more</a></p>
                        </div>
                        <h3 class="b-accordion__title f-accordion__title f-primary-b"><i
                                class="fa fa-question-circle"></i> Maecenas augue ante, euismod vitae egestas </h3>

                        <div class="b-accordion__content">
                            <p>Mauris rhoncus pretium porttitor. Cras scelerisque commodo odio. Phasellus dolor enim,
                                faucibus egestas scelerisque hendrerit, aliquet sed lorem. Pellentesque et pulvinar
                                enim. Quisque at tempor ligula. Maecenas augue ante, euismod vitae egestas sit amet,
                                accumsan eu nulla. <br/>
                                <a href="blog_detail_left_slidebar.html" class="f-more f-primary-b">Read more</a></p>
                        </div>
                        <h3 class="b-accordion__title f-accordion__title f-primary-b"><i
                                class="fa fa-question-circle"></i> Donec ut purus sed tortor malesuada venenatis eget
                        </h3>

                        <div class="b-accordion__content">
                            <p>Mauris rhoncus pretium porttitor. Cras scelerisque commodo odio. Phasellus dolor enim,
                                faucibus egestas scelerisque hendrerit, aliquet sed lorem. Pellentesque et pulvinar
                                enim. Quisque at tempor ligula. Maecenas augue ante, euismod vitae egestas sit amet,
                                accumsan eu nulla. <br/>
                                <a href="blog_detail_left_slidebar.html" class="f-more f-primary-b">Read more</a></p>
                        </div>
                        <h3 class="b-accordion__title f-accordion__title f-primary-b"><i
                                class="fa fa-question-circle"></i> Suspendisse vitae lectus in tellu</h3>

                        <div class="b-accordion__content">
                            <p>Mauris rhoncus pretium porttitor. Cras scelerisque commodo odio. Phasellus dolor enim,
                                faucibus egestas scelerisque hendrerit, aliquet sed lorem. Pellentesque et pulvinar
                                enim. Quisque at tempor ligula. Maecenas augue ante, euismod vitae egestas sit amet,
                                accumsan eu nulla. At vero eos et accusamus et iusto odio dignissimos ducimus qui
                                blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas. <br/>
                                <a href="blog_detail_left_slidebar.htmll" class="f-more f-primary-b">Read more</a></p>
                        </div>
                        <h3 class="b-accordion__title f-accordion__title f-primary-b"><i
                                class="fa fa-check-circle-o"></i> Morbi sagittis, sem quis lacinia faucibus, orci ipsum
                            gravida tortor ? </h3>

                        <div class="b-accordion__content">
                            <p>Mauris rhoncus pretium porttitor. Cras scelerisque commodo odio. Phasellus dolor enim,
                                faucibus egestas scelerisque hendrerit, aliquet sed lorem. Pellentesque et pulvinar
                                enim. Quisque at tempor ligula. Maecenas augue ante, euismod vitae egestas sit amet,
                                accumsan eu nulla. <br/>
                                <a href="blog_detail_left_slidebar.html" class="f-more f-primary-b">Read more</a></p>
                        </div>
                        <h3 class="b-accordion__title f-accordion__title f-primary-b"><i
                                class="fa fa-check-circle-o"></i> Maecenas augue ante, euismod vitae egestas </h3>

                        <div class="b-accordion__content">
                            <p>Mauris rhoncus pretium porttitor. Cras scelerisque commodo odio. Phasellus dolor enim,
                                faucibus egestas scelerisque hendrerit, aliquet sed lorem. Pellentesque et pulvinar
                                enim. Quisque at tempor ligula. Maecenas augue ante, euismod vitae egestas sit amet,
                                accumsan eu nulla. <br/>
                                <a href="blog_detail_left_slidebar.html" class="f-more f-primary-b">Read more</a></p>
                        </div>
                    </div>

                    <section
                            class="b-infoblock-with-icon-group b-infoblock-with-icon--small-indent row b-infoblock-with-icon--sm f-infoblock-with-icon--sm b-infoblock-with-icon--biggest-icons b-infoblock-with-icon--center f-infoblock-with-icon--center b-default-top-indent">
                        <div class="col-md-4 col-sm-6 col-xs-12 b-null-bottom-indent">
                            <div class="b-infoblock-with-icon">
                                <a href="contact_us_v2.html"
                                   class="b-infoblock-with-icon__icon f-infoblock-with-icon__icon fade-in-animate">
                                    <i class="fa fa-comments"></i>
                                </a>

                                <div class="b-infoblock-with-icon__info f-infoblock-with-icon__info">
                                    <a href="contact_us_v2.html"
                                       class="f-infoblock-with-icon__info_title b-infoblock-with-icon__info_title f-title-big f-primary-sb">Live
                                        chat with us</a>

                                    <div class="f-infoblock-with-icon__info_text b-infoblock-with-icon__info_text">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut massa in.
                                        At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis
                                        praesentium voluptatum deleniti atque c
                                    </div>
                                    <p><a class="f-more f-primary-b" href="contact_us_v2.html">Read more </a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12 b-null-bottom-indent">
                            <div class="b-infoblock-with-icon">
                                <a href="contact_us_v2.html"
                                   class="b-infoblock-with-icon__icon f-infoblock-with-icon__icon fade-in-animate">
                                    <i class="fa fa-headphones"></i>
                                </a>

                                <div class="b-infoblock-with-icon__info f-infoblock-with-icon__info">
                                    <a href="contact_us_v2.html"
                                       class="f-infoblock-with-icon__info_title b-infoblock-with-icon__info_title f-title-big f-primary-sb">Free
                                        call for all</a>

                                    <div class="f-infoblock-with-icon__info_text b-infoblock-with-icon__info_text">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut massa in.
                                        At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis
                                        praesentium voluptatum deleniti atque c
                                    </div>
                                    <p><a class="f-more f-primary-b" href="contact_us_v2.html">Read more </a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12 b-null-bottom-indent">
                            <div class="b-infoblock-with-icon">
                                <a href="contact_us_v2.html"
                                   class="b-infoblock-with-icon__icon f-infoblock-with-icon__icon fade-in-animate">
                                    <i class="fa fa-comments"></i>
                                </a>

                                <div class="b-infoblock-with-icon__info f-infoblock-with-icon__info">
                                    <a href="contact_us_v2.html"
                                       class="f-infoblock-with-icon__info_title b-infoblock-with-icon__info_title f-title-big f-primary-sb">Forum
                                        support</a>

                                    <div class="f-infoblock-with-icon__info_text b-infoblock-with-icon__info_text">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut massa in.
                                        At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis
                                        praesentium voluptatum deleniti atque c
                                    </div>
                                    <p><a class="f-more f-primary-b" href="contact_us_v2.html">Read more </a></p>
                                </div>
                            </div>
                        </div>
                    </section>

                </div>
                <aside class="col-md-3">
                    <div>
                        <h4 class="f-primary-b b-h4-special f-h4-special c-primary">search</h4>

                        <div class="b-form-row b-input-search">
                            <input class="form-control" type="text" placeholder="Enter your keywords"/>
                            <span class="b-btn b-btn-search f-btn-search fa fa-search"></span>
                        </div>
                    </div>
                    <div class="b-categories-filter b-default-top-indent">
                        <h4 class="f-primary-b b-h4-special f-h4-special c-primary">knowledge base</h4>
                        <ul>
                            <li>
                                <a class="f-categories-filter_name" href="#"><i class="fa fa-plus"></i> Web Design</a>
                                <span class="b-categories-filter_count f-categories-filter_count">12</span>
                            </li>
                            <li>
                                <a class="f-categories-filter_name" href="#"><i class="fa fa-plus"></i> Smart Phone</a>
                                <span class="b-categories-filter_count f-categories-filter_count">23</span>
                            </li>
                            <li>
                                <a class="f-categories-filter_name" href="#"><i class="fa fa-plus"></i> Latop</a>
                                <span class="b-categories-filter_count f-categories-filter_count">12</span>
                            </li>
                            <li>
                                <a class="f-categories-filter_name" href="#"><i class="fa fa-plus"></i> Apple Store</a>
                                <span class="b-categories-filter_count f-categories-filter_count">23</span>
                            </li>
                            <li>
                                <a class="f-categories-filter_name" href="#"><i class="fa fa-plus"></i> Wordpress Theme</a>
                                <span class="b-categories-filter_count f-categories-filter_count">12</span>
                            </li>
                            <li>
                                <a class="f-categories-filter_name" href="#"><i class="fa fa-plus"></i> Web Design</a>
                                <span class="b-categories-filter_count f-categories-filter_count">23</span>
                            </li>
                            <li>
                                <a class="f-categories-filter_name" href="#"><i class="fa fa-plus"></i> Sport</a>
                                <span class="b-categories-filter_count f-categories-filter_count">12</span>
                            </li>
                            <li>
                                <a class="f-categories-filter_name" href="#"><i class="fa fa-plus"></i> Fashion</a>
                                <span class="b-categories-filter_count f-categories-filter_count">23</span>
                            </li>
                        </ul>
                    </div>
                    <div class="b-default-top-indent">
                        <h4 class="f-primary-b b-h4-special f-h4-special c-primary">submit your questions</h4>

                        <div class="b-form-row">
                            <input type="text" class="form-control" placeholder="Your email"/>
                        </div>
                        <div class="b-form-row">
                            <input type="text" class="form-control" placeholder="Subject"/>
                        </div>
                        <div class="b-form-row">
                            <textarea class="form-control" placeholder="Your questions" rows="5"></textarea>
                        </div>
                        <div class="b-form-row">
                            <a href="#" class="b-btn f-btn b-btn-md b-btn-default f-primary-b b-btn__w100">submit
                                questions</a>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </section>
@stop
@section('customscript')


@stop