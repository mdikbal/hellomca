
    <div class="b-slidercontainer">
    <div class="b-slider j-fullscreenslider">
        <ul>
            <li data-transition="3dcurtain-vertical" data-slotamount="7">
                <div class="tp-bannertimer"></div>
                {!! Html::image('assets/frontend/img/slider/slider-lg__bg.png','',array('data-retina' => 'data-retina')) !!}
                <div class="caption sfb"  data-x="center" data-y="bottom" data-speed="700" data-start="1700" data-easing="Power4.easeOut" style="z-index: 2">
                
                    {!! Html::image('assets/frontend/img/slider/slider_main_2-1.png','',array('data-retina' => 'data-retina')) !!}
                    
                </div>
                <div class="caption sfl"  data-x="50" data-y="bottom" data-speed="700" data-start="2500" data-easing="Power4.easeOut">
                    {!! Html::image('assets/frontend/img/slider/slider_main_2-2.png','',array('data-retina' => 'data-retina')) !!}
                </div>
                <div class="caption sfr"  data-x="right" data-y="bottom" data-hoffset="-30" data-speed="700" data-start="2500" data-easing="Power4.easeOut">
                    {!! Html::image('assets/frontend/img/slider/slider_main_2-3.png','',array('data-retina' => 'data-retina')) !!}
                </div>
                <div class="caption lft"  data-x="center" data-y="30" data-speed="600" data-start="2600">
                    <h1 class="f-primary-b c-white" >awesome psd template</h1>
                </div>
                <div class="caption"  data-x="center" data-y="90" data-speed="600" data-start="3200">
                    <p class="f-primary-b f-slider-lg-item__text_desc f-center c-white" >
                        Multi-purposes template with 100+ psd files for Corporate, Travel, Education, Real Estate...
                        <br/>
                        and much more website
                    </p>
                </div>
            </li>
            <li data-transition="" data-slotamount="7">
                <div class="tp-bannertimer"></div>
                {!! Html::image('assets/frontend/img/slider/slider-lg__bg.png','',array('data-retina' => 'data-retina')) !!}                
                <div class="caption sfb"  data-x="right" data-y="bottom" data-speed="700" data-start="1700" data-easing="Power4.easeOut">
                    {!! Html::image('assets/frontend/img/slider/slider-ipad.png','',array('data-retina' => 'data-retina')) !!}
                </div>
                <div class="caption sfl"  data-x="right" data-y="bottom" data-speed="700" data-start="2500" data-easing="Power4.easeOut" style="z-index: 2">
                    {!! Html::image('assets/frontend/img/slider/slider-iphone.png','',array('data-retina' => 'data-retina')) !!}
                </div>
                <div class="caption lft"  data-x="left" data-y="112" data-speed="600" data-start="2600">
                    <h1 class="f-primary-b c-white" >Fully responsive design</h1>
                    <h3 class="f-primary-b c-white">Layer Slider wordpress plugin included</h3>
                </div>
                <div class="caption"  data-x="left" data-y="240" data-speed="600" data-start="3200">
                    <p class="f-primary-b f-slider-sm-item__text_desc c-white" >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque ex erat,<br /> venenatis a velit vel, pretium interdum sapien.
                    </p>
                </div>
                <div class="caption"  data-x="left" data-y="305" data-speed="800" data-start="3600">
                    <button class="button-lg">PURSHASE NOW</button>
                </div>
            </li>
            <li data-transition="" data-slotamount="7">
                <div class="tp-bannertimer"></div>
                {!! Html::image('assets/frontend/img/slider/slider-lg__bg.png','',array('data-retina' => 'data-retina')) !!}                
                <div class="caption sfb"  data-x="right" data-y="70" data-speed="700" data-start="1700" data-easing="Power4.easeOut" style="z-index: 2">
                    {!! Html::image('assets/frontend/img/slider/slider-imac.png','',array('data-retina' => 'data-retina')) !!}
                </div>
                <div class="caption lft"  data-x="left" data-y="95" data-speed="600" data-start="2600">
                    <h2 class="f-primary c-white">frexy templates</h2>
                </div>
                <div class="caption lft"  data-x="left" data-y="135" data-speed="600" data-start="2600">
                    <h1 class="f-primary-b c-white b-bg-slider-title">modern. creative. unique</h1>
                </div>
                <div class="caption lft"  data-x="left" data-y="220" data-speed="600" data-start="2600">
                    <ul class="b-slider-list f-slider-list c-white">
                        <li>
                            <i class="fa fa-tablet"></i> <span>Responsive wordpress theme</span>
                        </li>
                        <li>
                            <i class="fa fa-cog"></i> <span>Easy to use and powerful theme options</span>
                        </li>
                        <li>
                            <i class="fa fa-trophy"></i> <span>Multi purpose with 10+ homepage layout</span>
                        </li>
                        <li>
                            <i class="fa fa-globe"></i> <span>Awesome icons included</span>
                        </li>
                        <li>
                            <i class="fa fa-spinner"></i> <span>Unlimited colors support</span>
                        </li>
                        <li>
                            <i class="fa fa-life-ring"></i> <span>Free setting-up and support</span>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>
</div>